

import math

def area_circle(r):
    return r * r * math.pi


