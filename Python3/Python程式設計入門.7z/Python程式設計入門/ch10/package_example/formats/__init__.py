
def foo():
    return 'foo'
    