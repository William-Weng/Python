

__all__= ['menu', 'canvas', 'display', 'draw']

def display():
    return 'display'
def draw():
    return 'draw'


