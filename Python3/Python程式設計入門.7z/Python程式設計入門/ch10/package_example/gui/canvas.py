
def clear():
    return 'clear'
    