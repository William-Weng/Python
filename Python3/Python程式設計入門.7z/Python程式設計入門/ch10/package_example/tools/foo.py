

def foo():
    return 'foo'

