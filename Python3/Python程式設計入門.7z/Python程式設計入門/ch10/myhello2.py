
# import mymath2
# print(mymath2._x)

# from mymath2 import _x
# print(_x)

# from mymath3 import *
# print(pi)
# print(x)

# from mymath3 import *
# print(pi)
# print(x)
# print(y)

from mymath3 import x
print(x)
