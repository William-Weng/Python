

__all__ = ['pi', 'gcd', 'factorial']
x = 'xxx'
y = 3
pi = 3.14
def gcd(a, b): pass
def factorial(n): pass
def z(): pass
