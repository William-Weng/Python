

def bar():
    return 'bar'
    