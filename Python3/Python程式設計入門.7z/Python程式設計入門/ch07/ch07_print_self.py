

with open('ch07_print_self.py') as fin:
    for line in fin:
        print(line)
