
scores = [60, 73, 81, 95, 34]
n = 0
total = 0
for x in scores:
    n += 1
    total += x

avg = total / n

print('total ' + str(total))
print('average ' + str(avg))
